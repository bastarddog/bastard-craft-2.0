@API(apiVersion = "8.0.0", owner = "Mekanism", provides = "MekanismAPI|laser")
package mekanism.api.lasers;
import cpw.mods.fml.common.API;