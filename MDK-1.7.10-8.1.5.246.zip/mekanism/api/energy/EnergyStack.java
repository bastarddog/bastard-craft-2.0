package mekanism.api.energy;

/**
 * Created by ben on 27/03/15.
 */
public class EnergyStack
{
	public double amount;

	public EnergyStack(double newAmount)
	{
		amount = newAmount;
	}
}
